After downloading the image folders (G2 images 1 & G2 images 2), create a new folder named "Images" and place the content of the folders in the "Images" folder.

Place the "Images" folder in the "CHPaP" folder with the html files.